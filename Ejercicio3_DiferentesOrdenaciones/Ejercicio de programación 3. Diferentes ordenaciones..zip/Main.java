//package diferentesOrdenaciones;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//import diferentesOrdenaciones.Ordenacion;

/*****************************************************************************************
 * 							 	 DIFERENTES ORDENACIONES 							 	 *	
 * 																						 *		
 * Ordenación de un array mediante sucesivos intercambios de dos posiciones contiguas.	 *	
 * 					Por ejemplo el algoritmo de la burbuja.								 *
 * 																						 *
 * Identificamos un intercambio de este tipo mediante el número de la primera posición 	 *
 * que interviene en el mismo.  														 *
 * 																						 *
 * Secuencia de intercambios sería una secuencia de números representando cada uno de 	 *
 * 	ellos una posición en el array. 													 *
 * 																						 *
 * Un array llamado 'a' de 3 posiciones contiene los números valores 30 20 y 10, si 	 *
 * numeramos las posiciones como en java comenzando en 0, la secuencia 1 0 1 			 *
 * representaría los intercambios: a[1] con a[2], a[0] con a[1] y a[1] con a[2].  		 *
 * 																						 *
 * Esa secuencia ordena el array, no es la única, la secuencia 0 1 0 también ordenaría'a'*
 * 																						 *
 * Dado un array cualquiera, ¿cuántas formas de ordenarlo mediante intercambios de 		 *
 * posiciones contiguas existen?														 *
 * 																						 *
 * Existen infinitas a toda secuencia se podrían añadir parejas de intercambios iguales  *
 * y que no afectan al orden final, la secuencia 0 0 0 1 0 también ordena el array 'a',  *
 * pero también la 0 0 0 0 0 1 0, etc. 													 *
 * 																						 *
 * Sin embargo, existirán secuencias de longitud mínima. 								 *
 * 																						 *
 * Dar, para un array concreto, el número de ordenaciones distintas de longitud 		 *
 * mínima que existen para ordenarlo usando intercambios de posiciones contiguas. 		 *
 * 																						 *
 * Entrada: varios Arrays, uno por línea. 1º número n que da el nº de pos del Array 	 *
 *  		Seguido de n nº(contenido del array)Finalizará con una línea conteniendo un 0*
 *  																					 *
 * Salida: para cada uno de ellos el número de ordenaciones distintas por intercambios de*
 *  posiciones contiguas de longitud mínima que existen.								 *
 *  																					 *  
 ****************************************************************************************/

public class Main {
	
	/*
	 * Método principal main, 1º en ejecutarse, 
	 */
	public static void main(String[] args) {
		
		String entrada;
		int a[] = null;
		int num;
		int res = 0;
		List<int []> vectores = new ArrayList<int []>();
		Scanner teclado = new Scanner(System.in);
		
		while(teclado.hasNext()) {
						
			entrada = teclado.next();
			if(entrada.equals(" ")) {
				entrada = teclado.next();
			}
			else {
				num = Integer.parseInt(entrada);
				//Si la entrada es 0 salimos
				if(num == 0) {
					teclado.close();
					break;	//bucle
				}
				else {
					a = new int[num];
					for(int i = 0; i < num; i++) {
						entrada = teclado.next();
						a[i] = Integer.parseInt(entrada);
					}
					vectores.add(a);
				}
			}	
		}
		teclado.close();

		for(int i = 0; i < vectores.size(); i++) {
			res = 0;
			//Si el vector esta ordenado
			if(ordenado(vectores.get(i))==true) {
				res += 0;
			}
			else {
				res = comp(vectores.get(i));
			}
			if(res == 1) {
				System.out.println("Hay "+res+" forma de ordenar el array "+(i+1)+".");
			}
			else {
				System.out.println("Hay "+res+" formas de ordenar el array "+(i+1)+".");
			}
		}	
	
	}	
		/*
		 * Método Comprueba si esta ordenado 
		 */
		public static boolean ordenado(int[] A) {
			boolean res = false;
			for(int i = 0; i < A.length - 1; i++) {
				if(A[i]<A[i + 1]) {
					res = true;
				}
				else {
					res = false;
					i = A.length;
				}
			}
			return res;
		}
			
		/*
		 * Método que ordena el array
		 */
		public static int comp(int[]A) {
			
			int[] B = new int[A.length];
			List<Integer> D = new ArrayList<Integer>();
			D.clear();
			int res = 0;	//contador ordena individual.
			int aux;
	
			
			for(int i = 0; i < A.length - 1; i++) {	
				
				//Copio el array
				for(int k = 0; k < A.length; k++) {
					B[k] = A[k];
				}			
				if(B.length == 2) {
					if(B[i] > B[i + 1]) {			//Compruebo si el primer elemento es mayor que el segundo.
						aux = B[i];
						B[i] = B[i + 1];
						B[i + 1] = aux;
						if(ordenado(B) == true) {
							res += 1;				//Si lo es aumento el contador de respuestas
						}
					}
				}
				else {
					if(B[i] > B[i + 1]) {			//Compruebo si el primer elemento es mayor que el segundo.
						aux = B[i];
						B[i] = B[i + 1];
						B[i + 1] = aux;
						if(ordenado(B) == true) {
							res += 1;				//Si lo es aumento el contador de respuestas
						}
						else {			
							D.add(i);	
							res += comp2(B, D);		//Llamo a funcion comp2 que comparará
						}
					}
				}
			}
			return res;
		}
		
		/*
		 * Método que ordena el array2
		 */
		public static int comp2(int[]A, List<Integer> D) {
			
			int res = 0;	//contador ordena individual.
			int aux;
			int num;
			
			for(int i = 0; i < A.length - 1; i++) {	
				aux = D.size();
				num = D.get(aux-1);
				if(i != num) {						//Si el num que nos pasaron es distinto que el que vamos a coger
					if(A[i] > A[i+1]) {				//Compruebo si el primer elemento es mayor que el segundo. 	//0 = 20 > 30? NO 1 = 30 > 10? SI
						//System.out.println("Numero: "+num+" i: "+i);
						aux = A[i];
						A[i] = A[i + 1];
						A[i + 1] = aux;
						if(ordenado(A) == true) {
							res += 1;				//Si lo es aumento el contador de respuestas
						}
						else {	
							D.add(i);	
							res = comp2(A, D);
						}
					}
				}
			}
			return res;
		}
	
	/************************************************
	 * 												*
	 * ENTRADA: 									*
	 *  											*
	 * 		2 9 7 									*
	 * 		2 12 50 								*
	 * 		3 3 2 1 								*
	 * 		3 9 1 5 								*
	 * 		0 										*
	 *  											*
	 * SALIDA: 										*
	 * 												*
	 * 		Hay 1 forma de ordenar el array 1.		*
	 * 		Hay 0 formas de ordenar el array 2.		*
	 * 		Hay 2 formas de ordenar el array 3.		*
	 * 		Hay 1 forma de ordenar el array 4.		*
	 * 												* 
	 ***********************************************/
/*	
2 9 7
2 12 50
3 3 2 1
3 9 1 5
0
*/
}
