

import java.util.ArrayList;
import java.util.Scanner;

/**
 Un profesor ha puesto el siguiente reto a sus alumnos para saber quién puede aplicar mejor un código conocido. Les dará como entrada un 
 
 número entero positivo k que representa un conjunto de k tableros de ajedrez. Cada tablero tendrá 8 reinas y cada una de sus casillas  
 
 contendrá un número del 1 al 99. El programa que construya cada alumno deberá dar la máxima puntuación que se puede obtener para cada 
 
 tablero sumando el valor de cada casilla ocupada por una reina cuando éstas se colocan formando una solución al problema de las 8 reinas, 
 
 es decir se colocan sin que se ataquen ni por fila, ni por columna ni de forma diagonal.

La entrada contendrá el número k en la primera fila y a continuación k conjuntos de 8 líneas. Cada bloque de 8 líneas da por filas los 

valores enteros entre 1 y 99 que contiene cada casilla de cada tablero. Cada valor está separado por un único blanco.

La salida serán k filas en las que en cada una de ellas se da el valor máximo alcanzable en cada uno de los tableros.

Ejemplo

Entrada

1
1 2 3 4 5 6 7 8
9 10 11 12 13 14 15 16
17 18 19 20 21 22 23 24
25 26 27 28 29 30 31 32
33 34 35 36 37 38 39 40
41 42 43 44 45 46 47 48
48 50 51 52 53 54 55 56
57 58 59 60 61 62 63 64
Salida

260
 * @author adolfo
 *
 */

public class Main {
	private static final int NREINAS = 8;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		int nt = sc.nextInt();
		
		// Calculo todas las soluciones al problema de las 8-reinas
		NReinasEsquema nr = new NReinasEsquema(NREINAS);
		ArrayList<int[]> soluciones = new ArrayList<int[]>();
		nr.reinas(soluciones);
	
	    // Calculo el máximo valor alcanzado para las puntuaciones de cada tablero	
		for (int i=0; i<nt; i++) {
			int[][] valoresTablero = leerTablero(sc, NREINAS);
			
			int maxValor = 0;
			for (int[] sol : soluciones) {
				int nuevoValor = calculaSuma(sol,valoresTablero);
				if (nuevoValor > maxValor)
					maxValor = nuevoValor;
			}
			System.out.println(maxValor);
			
		}
		sc.close();
	}

	/**
	 * Calcula la suma de los valores de las casillas dadas en 
	 * valoresTableros con la solución al problema de las 8
	 * reinas dada en sol.
	 * 
	 * @param sol
	 * @param valoresTablero
	 * @return
	 */
	private static int calculaSuma(int[] sol, int[][] valoresTablero) {
		int suma = 0;
		for (int i = 0; i < sol.length; i++) {
			suma += valoresTablero[i][sol[i]];
		}
		return suma;
	}

	/**
	 * Lee un tablero de tam líneas y de tam números desde sc y lo 
	 * devuelve.
	 * 
	 * Prec: el tablero está bien formado
	 * @param sc
	 * @return
	 */
	private static int[][] leerTablero(Scanner sc, int tam) {
		int[][] res = new int[tam][tam];
		for (int i=0; i < tam; i++ ) {
			for (int j=0; j < tam; j++) {
				res[i][j] = sc.nextInt();
			}
		}
		return res;
	}

}
