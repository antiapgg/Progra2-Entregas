

/**
 * Implementa en Java la solución al problema de las n reinas dado en los apuntes de clase.
 */
import java.util.ArrayList;

public class NReinasEsquema {

/**
 * almacena el tamaño del tablero. Eso determina el número de reinas a colocar.
 */
	int tam;
 
 NReinasEsquema(int n){
     tam = n;
    }
 
 /**
  * Devuelve verdadero si y sólo si hay conflicto por columna o por diagonal entre la reina colocada en la fila k de tab con cualquier
  * otra reina colocada en las filas 0 a k-1.
  * 
  * @param tab la posición de las reinas en columnas hasta la fila k
  * @param k fila de la reina a evaluar con las reinas anteriores
  * @return true hay conflicto entre el valor tab[k] y cualquier tab[i] con i < k por fila o por diagonal, false si no lo hay.
  */
 public boolean hayConflicto (int[] tab,int k){
        int i = 0;
        while (i < k){
            if (tab[i] == tab[k] || Math.abs(tab[i]-tab[k]) == k-i)
                return true;
            i++;
        }
        return false;            
     }
 
 /**
  * Devuelve todas las soluciones posibles al problema de las n reinas con tam=n
  * @param soluciones Almacena las soluciones encontradas.
  */
 public void reinas (ArrayList<int[]> soluciones){
     int[] solucion = new int[tam];
     for (int i=0; i<tam;i++)
         solucion[i] = -1;
     
     reinasVueltaAtras(solucion,0,soluciones);
  
     }
 /**
  * Añade a sols todas las soluciones encontradas al problema de las n-reinas a partir de la solución parcial dada en sol hasta la 
  * posición fila-1. 
  * @param sol solución parcial construida hasta el momento. 
  * 
  * Precondición: !hayConflcito(sol,fila-1)
  * 
  * @param fila fila que toca poner una nueva reina. Precondición: 0 <= fila < tam 
  * @param sols
  */
 private void reinasVueltaAtras(int[] sol, int fila, ArrayList<int[]> sols){
     for (int i=0; i<tam; i++){
         sol[fila] = i;
         if (!hayConflicto(sol,fila))
             if (fila==tam-1){
                 int[] nuevaSol = new int[tam];
                 for (int j=0; j<tam;j++)
                     nuevaSol[j] = sol[j];
                 sols.add(nuevaSol);
             }
            else
                 reinasVueltaAtras(sol,fila+1,sols);
     }
 }
}
